# rw_socket_driver
Driver that uses network sockets to communicate with client and read/ write protected process memory.

[KSOCKET](https://github.com/wbenny/KSOCKET) is used to create network socket in kernel. Driver is adapted to work as manualmapped.
