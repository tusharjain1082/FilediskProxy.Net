#pragma once

// C & C++
#include <stddef.h>
#include <stdlib.h>

// System
#include <intrin.h>
#include <ntddk.h>
#include <wdm.h>
#include <wsk.h>

// Global
static constexpr auto WSK_POOL_TAG = ' KSW'; // 'WSK '
